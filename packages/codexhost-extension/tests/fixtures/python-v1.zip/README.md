# The Althing

Extract this folder and open index.html locally. Reports are in reports/.
Import the original ZIP to restore this council on another Althing server.
